package com.prc;

public class Test2 {
	public static void main(String[] args) {
		int a;
		a = 10;
		System.out.println(a);
	}
}
/*
primitive : in-built
non-primitive : derived and user defined

java supports only DMA  (dynamic memory allocation)

int a;
int ar[] = new int[2];
Test2 m = new Test2();
*/